import { Injectable } from '@angular/core';
import { ICustomer } from 'src/app/TravelAway-interfaces/Customer';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  customer: ICustomer[];

  constructor(private http: HttpClient) { }
  validateCredentials(email: string, password: string): Observable<number> {
    let temp;
    var custObj: ICustomer;
    temp = this.http.post<number>('https://localhost:44347/api/Customer/ValidateLoginCustomer', { EmailId: email, UserPassword: password }).pipe(catchError(this.errorHandler));
    //if (loginRole == 1) {
    //  var custObj: ICustomer;
    //  temp = this.http.post<number>('https://localhost:44347/api/Customer/ValidateLoginCustomer', { EmailId: email, UserPassword: password }).pipe(catchError(this.errorHandler));
    //  //custObj = { EmailId: email, UserPassword: password, FirstName: null, LastName: null, RoleId: null, Gender: null, DateOfBirth: null, Address: null, ContactNumber: null };
    //  temp = this.http.post<number>('https://localhost:44347/api/Customer/ValidateLoginCustomer', { EmailId: email, UserPassword: password }).pipe(catchError(this.errorHandler));
    //}
    //else if(loginRole == 2){
    //  var EmpObj = IEmployee;
    //  EmpObj = { EmailId: email, UserPassword: password, FirstName: null, LastName: null, RoleId: null };
    //  temp = this.http.post<number>('https://localhost:44347/api/Customer/', EmpObj).pipe(catchError(this.errorHandler));
    //}
    return temp;
  }

  addUserDetails(firstname: string, lastname: string, emailid: string, password: string, contactnumber: number, address: string, gender: string, dateofbirth: Date, roleId: number): Observable<number> {
    var custObj: ICustomer
    custObj = {
      EmailId: emailid, UserPassword: password, FirstName: firstname, LastName: lastname, RoleId: roleId,
      Gender: gender, DateOfBirth: dateofbirth, Address: address, ContactNumber: contactnumber
    };
    let temp = this.http.post<number>('https://localhost:44347/api/Customer/AddCustomer', custObj).pipe(catchError(this.errorHandler));
    return temp;
  }

  validateEmployeeCredentials(email: string, password: string): Observable<number> {
    let temp;
    //var Obj: ICustomer;
    temp = this.http.post<number>('https://localhost:44347/api/Customer/EmployeeLogin', { EmailId: email, Password: password }).pipe(catchError(this.errorHandler));
    return temp;
  }
    errorHandler(error: HttpErrorResponse) {
      console.error(error);
      return throwError(error.message || "Server Error");
    }
  }

