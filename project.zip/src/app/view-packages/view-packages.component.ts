import { Component, OnInit } from '@angular/core';
import { PackageService } from '../TravelAwayServices/Package-Service/package.service';
import { IPackage } from '../TravelAway-interfaces/Package';
import { ICategory } from '../TravelAway-interfaces/Category';
import { CustomerService } from '../TravelAwayServices/Customer-Service/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-packages',
  templateUrl: './view-packages.component.html',
  styleUrls: ['./view-packages.component.css']
})
export class ViewPackagesComponent implements OnInit {

  searchByPackageName: string;
  searchByCategoryId: string = "0";
  imageSrc: string;
  showMsgDiv: boolean = false;
  message: string;
  errMsg: string;
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  packages: IPackage[];
  categories: ICategory[];
  filteredPackages: IPackage[];


  constructor(private _packageService: PackageService, private _customerService: CustomerService, private router: Router) {
    this.userRole = sessionStorage.getItem('userRole');
    //this.userRole = sessionStorage.getItem('firstName');
    //this.userRole = sessionStorage.getItem('lastName');
    if (this.userRole == "Customer") {
      this.customerLayout = true;
    }
    else {
      this.commonLayout = true;
    }
  }

  ngOnInit() {
    this.getPackages();
    this.getCategories();

    if (this.packages == null) {
      this.showMsgDiv = true;
    }

    this.filteredPackages = this.packages;
  }

  getPackages() {

    this._packageService.getPackages().subscribe(
      responsePackageData => {
        this.packages = responsePackageData;
        this.filteredPackages = responsePackageData;
        this.showMsgDiv = false;
        console.log("Inside GetPackages Method")
      },
      responsePackageError => {
        this.packages = null;
        this.errMsg = responsePackageError;
        console.log(this.errMsg);
      },
      () => console.log("GetPackages method executed successfully")
    );
  }

  getCategories() {
    this._packageService.getCategories().subscribe(
      responseCategoryData => this.categories = responseCategoryData,
      responseCategoryError => {
        this.categories = null;
        this.errMsg = responseCategoryError;
        console.log(this.errMsg);
      },
      () => console.log("GetCategories method executed successfully")
    );
  }

  searchPackage(packageName: string) {
    if (this.searchByCategoryId == "0") {
      this.filteredPackages = this.packages;
    }
    else {
      this.filteredPackages = this.packages.filter(pack => pack.PackageCategoryId.toString() == this.searchByCategoryId);
    }
    if (packageName != null || packageName == "") {
      this.searchByPackageName = packageName;
      this.filteredPackages = this.filteredPackages.filter(pack => pack.PackageName.toLowerCase().indexOf(packageName.toLowerCase()) >= 0);
    }
    if (this.filteredPackages.length == 0) {
      this.showMsgDiv = true;
      console.log("searchPackage method executed successfully")
    }
    else {
      this.showMsgDiv = false;
    }
  }

  viewPackageDetails(packageId: number, packageName: string) {
    console.log(packageId);
    console.log("Hi");
    this.router.navigate(['viewPackageDetails', packageId, packageName]);
    console.log(this.router.navigate(['viewPackageDetails', packageId, packageName]));
    console.log("Hi2");
  }


  //sagar
  //searchPackageByCategory(categoryId: string) {
  //  this.filteredPackages = this.packages;

  //  var catId = parseInt(categoryId)
  //  if (catId > 0) {
  //    this.filteredPackages = this.filteredPackages.filter(pack => pack.PackageCategoryId == catId);
  //  }
  //  console.log(this.filteredPackages);
  //}

  //nitin
  //searchPackageByCategory(categoryId: string) {
  //  this.filteredPackages = this.packages;
  //  if (categoryId == "0") {
  //    this.filteredPackages = this.packages;
  //    console.log("Search filter")
  //  }

  //  else {
  //    this.filteredPackages = this.filteredPackages.filter(pack => {
  //      return pack.PackageCategoryId.toString() === categoryId;
  //    });
  //  }
  //}



  //Sakshi
  searchPackageByCategory(categoryId: string) {
    if (this.searchByPackageName != null || this.searchByPackageName == "") {
      this.filteredPackages = this.packages.filter(pack => pack.PackageName.toLowerCase().indexOf(this.searchByPackageName.toLowerCase()) >= 0);
    }
    else {
      this.filteredPackages = this.packages;
    }
    this.searchByCategoryId = categoryId;
    if (this.searchByCategoryId == "0") {
      this.filteredPackages = this.packages;
    }
    else {
      this.filteredPackages = this.filteredPackages.filter(pack => pack.PackageCategoryId.toString() == this.searchByCategoryId);
    }
  }
}





    //this.packages =
    //[
    //  { PackageId: 2000, PackageName: "Southh India", PackageCategoryId: 100, TypeOfPackage: "Domestic" }
    //]

    //this.categories = [
    //  { PackageCategoryId: 100, PackageCategoryName: "Adventure" },
    //  { PackageCategoryId: 101, PackageCategoryName: "Nature" },
    //  { PackageCategoryId: 102, PackageCategoryName: "Religious" },
    //  { PackageCategoryId: 103, PackageCategoryName: "Village" },
    //  { PackageCategoryId: 104, PackageCategoryName: "Wildlife" }]
