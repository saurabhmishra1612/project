import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from "@angular/core";
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/customer-login/login.component';
import { EmployeeLoginComponent } from './login/employee-login/employee-login.component';
import { ViewPackagesComponent } from './view-packages/view-packages.component';
import { RegisterComponent } from './register/register.component';
import { LogoutComponent } from './logout/logout.component';
import { ViewPackageDetailsComponent } from './view-package-details/view-package-details.component';
import { AuthGuardService } from './TravelAwayServices/auth-service/auth-guard.service';
import { HotelComponent } from './hotel/hotel.component';
import { AddVehicleComponent } from './add-vehicle/add-vehicle.component';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'employee-login', component: EmployeeLoginComponent},
  { path: 'view-packages', component: ViewPackagesComponent, canActivate: [AuthGuardService] },
  { path: 'viewPackageDetails/:packageId/:packageName', component: ViewPackageDetailsComponent },
  { path: 'view-package-details', component: ViewPackageDetailsComponent },
  { path: 'hotel', component: HotelComponent },
  { path: 'add-vehicle', component: AddVehicleComponent },
  { path: 'logout', component: LogoutComponent },
  { path: '**', component: HomeComponent }
];
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
