export interface IVehicle {
  VehicleName: string
  VehicleType: string
  RatePerHour: number
  RatePerKM: number
  BasePrice: number
}
