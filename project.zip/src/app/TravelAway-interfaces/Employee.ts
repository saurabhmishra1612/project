export interface IEmployee {
  EmailId: string
  RoleId: number
  FirstName: string
  LastName: string
  Password: string
  EmpId:number
}
