export interface IPackage {
  PackageId: number
  PackageName: string
  PackageCategoryId: number
  TypeOfPackage:string
}
